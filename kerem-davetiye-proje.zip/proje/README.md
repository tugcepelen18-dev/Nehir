# Kerem — Doğum Günü Davetiyesi (Premium Mobil Web)

Referans tasarım **piksel seviyesinde korunmuştur**. Hiçbir karakter, renk, yazı tipi,
obje, yerleşim veya boyut değiştirilmemiştir. Tüm katman varlıkları referans görselden
**kesilerek** üretilmiştir; hiçbiri yeniden çizilmemiş veya AI ile üretilmemiştir.

## Dosya yapısı

```
index.html          Sahne, katmanlar, popup'lar
style.css           Konumlandırma + animasyonlar (yalnızca transform/opacity)
script.js           Koreografi, geri sayım, etkileşimler, AYAR bloğu
assets/
  sahne.webp                  Nihai tasarım (dokunulmamış)
  katmanlar/
    arkaplan.webp             Tren çıkarılmış arka plan (yalnızca girişte görünür)
    tren.webp                 Tren + karakterler (şeffaf kesim)
    tekerlek-0/1.webp         Dönen tekerlekler
    p-*.webp                  Sırayla belirecek tasarım parçaları (birebir kesim)
    doku-krem / doku-gok      Açılışta yazıyı gizleyen temiz doku örnekleri
```

## Teslimden önce düzenlenecek 4 satır — `script.js` içindeki `AYAR`

| Alan | Açıklama |
|---|---|
| `etkinlik` | Geri sayım hedefi. Şu an `2025-05-25T16:00:00+03:00` (geçmiş tarih → sayaç 00'da durur). **Gerçek tarihi girin.** |
| `whatsappNo` | Ülke kodu + numara, sadece rakam (örn. `905321234567`) |
| `haritaURL` | Parkın gerçek Google Maps bağlantısı |
| `girisAnimasyonu` | `false` yapılırsa davetiye açılış sahnesi olmadan doğrudan görünür |

## Açılış koreografisi

| Saniye | Olay |
|---|---|
| 0.0 – 2.0 | Yalnızca arka plan. Sessizlik (konfeti + bulut sakinliği) |
| 2.0 | Tren soldan gelir; tekerlekler döner, bacadan buhar çıkar |
| 5.4 | Tren ortada yavaşlayarak durur, tren düdüğü çalar |
| 5.5 | Giriş katmanı **nihai tasarıma çapraz geçer** → o andan itibaren ekranda birebir referans görsel vardır |
| 6.0 | Kamera tam kadraja açılır; davetiye kartı aşağıdan yukarı yay (spring) efektiyle girer |
| 7.0+ | Başlık → isim → yaş → bilgiler → butonlar → geri sayım sırayla fade + scale ile belirir |

Ekrana dokunulursa açılış atlanır ve davetiye anında açılır.

## Nasıl çalışır (teknik not)

Sıralı açılış, tasarımın üstüne çizim yapmadan şu yöntemle sağlanır:
her parça için (a) baked yazıyı gizleyen **temiz doku yaması** ve (b) orijinalden alınmış
**birebir dikdörtgen kesim** kullanılır. Kesim yerine oturduğunda ekrandaki piksel,
referans görselin aynısıdır — fark ölçülemez.

Tüm animasyonlar `transform` ve `opacity` ile çalışır (compositor katmanı, 60 FPS).
`will-change` yalnızca hareket eden katmanlarda tanımlıdır. `prefers-reduced-motion`
açık cihazlarda animasyonlar otomatik sadeleşir.

## Karakter mikro animasyonları (panda göz kırpma, tavşan kulak, aslan el sallama…)

Bu animasyonlar **her karakterin ayrı şeffaf PNG olmasını** gerektirir — düz bir
görselden bunları ayırmak karakterin kenarlarında hâle ve boşluk bırakır, yani tasarımı
bozar. Bu yüzden motor hazır bırakıldı, ama kapalı geliyor.

Tasarımcıdan katman referansındaki PNG'leri (şeffaf zeminli) alın ve şu adlarla
`assets/katmanlar/` içine koyun:

```
panda.png   tavsan.png   aslan.png   zurafa.png   balonlar.png
```

Dosyalar yerleştiği anda göz kırpma / el sallama / kulak oynatma / balon salınımı
otomatik devreye girer (`script.js` içindeki `KARAKTERLER` dizisinden konumlar
ince ayar yapılabilir). Dosya yoksa hiçbir şey değişmez.

## Müzik

İlk açılışta müzik **otomatik başlamaz** (tarayıcı kuralı ve tercih gereği).
Sağ üstteki "Müzik Aç" düğmesi açar/kapatır.
`assets/muzik.mp3` eklenirse o çalar; yoksa Web Audio ile üretilen kısa melodi devreye girer.
Tren düdüğü, kullanıcı ekrana bir kez dokunduysa çalar (iOS ses izni kuralı).

## Yayına alma

Statik barındırma yeterlidir (Netlify, Vercel, cPanel, GitHub Pages).
Klasörü olduğu gibi yükleyin. Sunucuda `.webp` MIME tipinin açık olduğundan emin olun.
Yerelde denemek için: `python3 -m http.server` ve `http://localhost:8000`.
(Dosyayı çift tıklayarak `file://` ile açarsanız bazı tarayıcılar katmanları engelleyebilir.)
