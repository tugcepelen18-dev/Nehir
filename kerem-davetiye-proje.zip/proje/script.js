/* ==========================================================================
   KEREM — DOĞUM GÜNÜ DAVETİYESİ  /  script.js
   Referans tasarım hiç değiştirilmez. Bu dosya yalnızca:
   koreografi (açılış), mikro animasyonlar, geri sayım ve etkileşimleri yönetir.
   ========================================================================== */

/* --------------------------------------------------------------------------
   1) AYARLAR — müşteriye teslimde yalnızca bu blok düzenlenir
   -------------------------------------------------------------------------- */
const AYAR = {
  cocuk        : "Kerem",
  etkinlik     : "2025-05-25T16:00:00+03:00",     // TARİH + SAAT (geri sayım hedefi)
  yerAdi       : "Mutluluk Parkı, İstanbul",
  haritaURL    : "https://www.google.com/maps/search/?api=1&query=Mutluluk+Parki+Istanbul",
  whatsappNo   : "905555555555",                  // ülke kodu + numara, sadece rakam
  whatsappMesaj: "Kerem'in doğum gününe katılacağım! 🎉",
  muzikDosyasi : "assets/muzik.mp3",              // yoksa Web Audio melodisi çalar
  girisAnimasyonu: true                           // false → davetiye doğrudan açılır
};

/* --------------------------------------------------------------------------
   2) TASARIM KOORDİNATLARI
   Tümü referans görselin doğal ölçüsüne (1024 x 1536) göredir ve
   yüzdeye çevrilerek uygulanır. Böylece her ekranda birebir oturur.
   -------------------------------------------------------------------------- */
const GW = 1024, GH = 1536;
const yuzde = (x, y, w, h) => ({
  left:  (x / GW * 100) + '%', top:    (y / GH * 100) + '%',
  width: (w / GW * 100) + '%', height: (h / GH * 100) + '%'
});

/* Trenin orijinaldeki yeri ve tekerlek merkezleri (görselden ölçülmüştür) */
const TREN      = [58, 254, 889, 423];
const TEKERLEK  = [ {x:276, y:626, r:33}, {x:428, y:608, r:50} ];

/* Sırayla belirecek tasarım parçaları: [x, y, en, boy, doku] */
const PARCALAR = [
  { ad:'ust-baslik', kutu:[238,  92, 552, 142], doku:'gok'  },
  { ad:'banner',     kutu:[352, 712, 322,  58], doku:'krem' },
  { ad:'isim',       kutu:[280, 772, 470, 112], doku:'krem' },
  { ad:'yas',        kutu:[296, 888, 438,  72], doku:'krem' },
  { ad:'mesaj',      kutu:[296, 966, 438, 104], doku:'krem' },
  { ad:'bilgi',      kutu:[192,1082, 652, 118], doku:'krem' },
  { ad:'butonlar',   kutu:[176,1226, 668, 136], doku:'krem' },
  { ad:'sayac',      kutu:[232,1348, 564, 158], doku:'krem' },
  { ad:'footer',     kutu:[326,1500, 376,  34], doku:'krem' }
];

/* Tasarımdaki butonların birebir konumları */
const HOTSPOT = {
  muzikHot : [842,  22, 168,  62],
  takvimHot: [186,1240, 236,  60],
  katilHot : [592,1240, 240,  60],
  konumHot : [632,1098, 200,  92]
};

const SAYAC_KUTU = [258, 1392, 500, 62];   // canlı rakamların oturacağı alan
const ALEV       = [459, 1188,  92, 92];   // pastadaki mum alevi ışığı
const BACA       = [178,  296];            // lokomotif bacası (buhar çıkışı)

const $  = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const sahne = $('#sahne'), kamera = $('#kamera'), efekt = $('#efekt');

/* --------------------------------------------------------------------------
   3) KATMANLARI YERLEŞTİR
   -------------------------------------------------------------------------- */
// Tren kutusu
Object.assign($('#trenKutu').style, yuzde(...TREN));

// Tekerlekler — tren kutusuna göre göreli konum
TEKERLEK.forEach((t, i) => {
  const el = document.querySelector(`.tekerlek[data-teker="${i}"]`);
  if (!el) return;
  el.style.left   = ((t.x - t.r - TREN[0]) / TREN[2] * 100) + '%';
  el.style.top    = ((t.y - t.r - TREN[1]) / TREN[3] * 100) + '%';
  el.style.width  = ((t.r * 2) / TREN[2] * 100) + '%';
  el.style.height = ((t.r * 2) / TREN[3] * 100) + '%';
});

// Butonlar
for (const [id, k] of Object.entries(HOTSPOT)) Object.assign($('#'+id).style, yuzde(...k));

// Sıralı açılış parçaları: örtü (baked yazıyı gizler) + parça (birebir kesim)
const kap = $('#sahneParcalari');
const dokuURL = { krem:'assets/katmanlar/doku-krem.webp', gok:'assets/katmanlar/doku-gok.webp' };
PARCALAR.forEach(p => {
  const ortu = document.createElement('div');
  ortu.className = 'ortu'; ortu.dataset.ad = p.ad;
  Object.assign(ortu.style, yuzde(...p.kutu));
  ortu.style.backgroundImage = `url(${dokuURL[p.doku]})`;
  ortu.style.backgroundSize  = p.doku === 'krem' ? '38% auto' : '55% auto';
  kap.appendChild(ortu);

  const parca = document.createElement('img');
  parca.className = 'parca'; parca.dataset.ad = p.ad; parca.alt = '';
  parca.src = `assets/katmanlar/p-${p.ad}.webp`;
  Object.assign(parca.style, yuzde(...p.kutu));
  kap.appendChild(parca);
});

// Mum alevi ışığı
const alev = document.createElement('div');
alev.id = 'alev'; Object.assign(alev.style, yuzde(...ALEV));
efekt.appendChild(alev);

/* Geri sayım kutusu — konum + doku + yazı boyutu (ölçüye duyarlı) */
const sayac = $('#sayac');
Object.assign(sayac.style, yuzde(...SAYAC_KUTU));
sayac.style.backgroundImage = `url(${dokuURL.krem})`;
function sayacOlcekle(){
  const h = sahne.clientHeight * (SAYAC_KUTU[3] / GH);
  sayac.style.setProperty('--rakam', (h * 0.92) + 'px');
  sayac.style.backgroundSize = (sahne.clientWidth * 0.19) + 'px auto';
}
sayacOlcekle();
addEventListener('resize', sayacOlcekle, {passive:true});

/* --------------------------------------------------------------------------
   4) SAHNE EFEKTLERİ (konfeti / buhar / ışıltı) — hepsi transform+opacity
   -------------------------------------------------------------------------- */
const RENK = ['#E07A54','#8A9A5B','#E8A33D','#7FA9A6','#EFC98E','#F2B0B0'];

function konfetiOlustur(adet = 22){
  const frg = document.createDocumentFragment();
  for (let i = 0; i < adet; i++){
    const k = document.createElement('span');
    k.className = 'konfeti';
    k.style.left = (Math.random() * 100) + '%';
    k.style.background = RENK[i % RENK.length];
    if (Math.random() > .5) k.style.borderRadius = '50%';
    k.style.animationDuration = (8 + Math.random() * 8) + 's';
    k.style.animationDelay    = (-Math.random() * 14) + 's';
    frg.appendChild(k);
  }
  efekt.appendChild(frg);
}

function buharOlustur(){
  for (let i = 0; i < 4; i++){
    const b = document.createElement('span');
    b.className = 'buhar';
    const c = 3.2 + Math.random() * 1.5;
    b.style.left = (BACA[0] / GW * 100) + '%';
    b.style.top  = (BACA[1] / GH * 100) + '%';
    b.style.width = c + '%'; b.style.aspectRatio = '1';
    b.style.animationDelay = (i * 0.9) + 's';
    efekt.appendChild(b);
  }
}

function isiltiOlustur(){
  [[560,246],[884,258],[938,330],[152,1348],[862,1358],[498,214]].forEach(([x,y], i) => {
    const s = document.createElement('span');
    s.className = 'isilti';
    s.style.left = (x / GW * 100) + '%';
    s.style.top  = (y / GH * 100) + '%';
    s.style.animationDelay = (i * .5) + 's';
    efekt.appendChild(s);
  });
}

konfetiOlustur(); buharOlustur(); isiltiOlustur();

/* --------------------------------------------------------------------------
   5) AÇILIŞ KOREOGRAFİSİ
   0.0s  arka plan + 2 sn sessizlik
   2.0s  tren soldan gelir (tekerlek döner, baca tüter)
   5.4s  tren ortada yavaşlayarak durur → düdük
   5.5s  giriş katmanı nihai tasarıma çapraz geçer (piksel birebir)
   6.0s  kamera tam kadraja açılır → davetiye kartı aşağıdan yukarı belirir
   7.0s  başlık → isim → yaş → bilgiler → butonlar → geri sayım sırayla
   -------------------------------------------------------------------------- */
const zamanlayicilar = [];
const beklet = (fn, ms) => zamanlayicilar.push(setTimeout(fn, ms));

function kameraAc(){
  kamera.classList.add('acildi');
  beklet(() => kamera.classList.add('nefes'), 1600);
}

function parcalariGoster(gecikme = 0, aralik = 190){
  PARCALAR.forEach((p, i) => {
    beklet(() => {
      document.querySelector(`.ortu[data-ad="${p.ad}"]`)?.classList.add('git');
      document.querySelector(`.parca[data-ad="${p.ad}"]`)?.classList.add('gel');
      if (p.ad === 'sayac') sayac.classList.add('gel');
    }, gecikme + i * aralik);
  });
  beklet(butonlariAc, gecikme + PARCALAR.length * aralik + 200);
}

function butonlariAc(){ $$('.hot').forEach(b => b.classList.add('aktif')); }

function girisiBitir(){
  $('#nihai').classList.add('gorunur');
  $('#giris').classList.add('gizli');
  beklet(() => $('#giris').style.display = 'none', 700);
}

function koreografiBaslat(){
  if (!AYAR.girisAnimasyonu) return hemenAc();

  beklet(() => {                      // 2 sn sessizlik → tren yola çıkar
    $('#trenKutu').classList.add('geldi');
  }, 2000);

  beklet(() => {                      // tren durdu
    $('#trenKutu').classList.add('durdu');
    dudukCal();
  }, 5400);

  beklet(girisiBitir, 5500);
  beklet(kameraAc,    6000);
  parcalariGoster(7000);
}

/* Girişi atla (ekrana dokunulursa) veya animasyonsuz aç */
function hemenAc(){
  zamanlayicilar.forEach(clearTimeout);
  $('#trenKutu').classList.add('geldi','durdu');
  girisiBitir(); kameraAc();
  $$('.ortu').forEach(o => o.classList.add('git'));
  $$('.parca').forEach(p => p.classList.add('gel'));
  sayac.classList.add('gel');
  butonlariAc();
}

let girisBitti = false;
sahne.addEventListener('pointerdown', e => {
  sesiAc();                                       // ses iznini ilk dokunuşta al
  if (girisBitti || e.target.closest('.hot, .modalArka')) return;
  girisBitti = true; hemenAc();
}, {passive:true});

addEventListener('load', () => {
  koreografiBaslat();
  beklet(() => girisBitti = true, 7000);
});

/* --------------------------------------------------------------------------
   6) SES — Web Audio (harici dosya gerekmez) + opsiyonel muzik.mp3
   Tarayıcı kuralı gereği ses ancak kullanıcı dokunuşundan sonra çalar.
   -------------------------------------------------------------------------- */
let ctx = null, melodiTimer = null, calan = false, mp3 = null;

function sesiAc(){
  if (!ctx) { try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch(e){} }
  if (ctx && ctx.state === 'suspended') ctx.resume();
}

function nota(freq, sure = .42, tip = 'sine', ses = .12){
  if (!ctx) return;
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = tip; o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, ctx.currentTime);
  g.gain.exponentialRampToValueAtTime(ses, ctx.currentTime + .04);
  g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + sure);
  o.connect(g).connect(ctx.destination);
  o.start(); o.stop(ctx.currentTime + sure + .02);
}

/* Tren düdüğü: iki komşu frekans + hafif gürültü hissi */
function dudukCal(){
  if (!ctx) return;                                  // izin yoksa sessiz geçer
  nota(392, .55, 'triangle', .10);
  nota(523, .55, 'triangle', .08);
  setTimeout(() => { nota(349, .8, 'triangle', .09); nota(466, .8, 'triangle', .06); }, 420);
}

const MELODI = [523.25,587.33,659.25,523.25, 523.25,587.33,659.25,523.25,
                659.25,698.46,783.99, 659.25,698.46,783.99];

function muzikAcKapa(){
  sesiAc();
  if (calan){
    clearInterval(melodiTimer); melodiTimer = null;
    if (mp3) mp3.pause();
    calan = false; bildir('Müzik kapandı');
    return;
  }
  calan = true; bildir('Müzik açıldı ♪');

  // Önce assets/muzik.mp3 denenir; yoksa Web Audio melodisine düşülür
  if (!mp3){
    mp3 = new Audio(AYAR.muzikDosyasi);
    mp3.loop = true; mp3.volume = .55;
  }
  mp3.play().catch(() => {
    let i = 0;
    const cal = () => nota(MELODI[i++ % MELODI.length]);
    cal(); melodiTimer = setInterval(cal, 480);
  });
}

/* --------------------------------------------------------------------------
   7) GERİ SAYIM
   -------------------------------------------------------------------------- */
const hedef   = new Date(AYAR.etkinlik).getTime();
const kutular = [0,1,2,3].map(i => document.getElementById('g' + i));

function sayimGuncelle(){
  const fark = Math.max(0, hedef - Date.now());
  const deger = [
    Math.floor(fark / 86400000),
    Math.floor(fark / 3600000) % 24,
    Math.floor(fark / 60000)   % 60,
    Math.floor(fark / 1000)    % 60
  ];
  deger.forEach((v, i) => {
    const yeni = String(v).padStart(2, '0');
    if (kutular[i].textContent !== yeni){
      kutular[i].textContent = yeni;
      kutular[i].classList.add('tik');
      setTimeout(() => kutular[i].classList.remove('tik'), 260);
    }
  });
}
sayimGuncelle(); setInterval(sayimGuncelle, 1000);

/* --------------------------------------------------------------------------
   8) ETKİLEŞİMLER
   -------------------------------------------------------------------------- */
let bildirimZaman;
function bildir(metin){
  const el = $('#bildirim');
  el.textContent = metin; el.classList.add('gor');
  clearTimeout(bildirimZaman);
  bildirimZaman = setTimeout(() => el.classList.remove('gor'), 2600);
}

// Dokunma dalgası
$$('.hot').forEach(b => b.addEventListener('click', () => {
  b.classList.remove('dalga'); void b.offsetWidth; b.classList.add('dalga');
}));

// Müzik
$('#muzikHot').addEventListener('click', muzikAcKapa);

// Takvime ekle → .ics indirir (iOS ve Android takvim uygulamaları destekler)
$('#takvimHot').addEventListener('click', () => {
  const bas = new Date(AYAR.etkinlik);
  const bit = new Date(bas.getTime() + 3 * 3600000);
  const f = d => d.toISOString().replace(/[-:]/g,'').split('.')[0] + 'Z';
  const ics = [
    'BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Davetiye//TR','CALSCALE:GREGORIAN',
    'BEGIN:VEVENT','UID:' + Date.now() + '@davetiye',
    'DTSTAMP:' + f(new Date()), 'DTSTART:' + f(bas), 'DTEND:' + f(bit),
    'SUMMARY:' + AYAR.cocuk + ' Doğum Günü Partisi',
    'LOCATION:' + AYAR.yerAdi,
    'DESCRIPTION:Doğum günümde sen de yanımda ol!',
    'END:VEVENT','END:VCALENDAR'
  ].join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([ics], {type:'text/calendar'}));
  a.download = AYAR.cocuk.toLowerCase() + '-dogum-gunu.ics';
  a.click(); URL.revokeObjectURL(a.href);
  bildir('Takvime eklendi 🗓️');
});

// Popup yönetimi
function modalAc(sec){
  const m = $(sec);
  m.classList.add('acik');
  m.querySelector('.mBtn')?.focus({preventScroll:true});
}
function modalKapat(m){ m.classList.remove('acik'); }
$$('.modalArka').forEach(m => {
  m.addEventListener('click', e => { if (e.target === m) modalKapat(m); });
  m.querySelector('.modalKapat').addEventListener('click', () => modalKapat(m));
  m.querySelectorAll('[data-kapat]').forEach(b => b.addEventListener('click', () => modalKapat(m)));
});
addEventListener('keydown', e => {
  if (e.key === 'Escape') $$('.modalArka.acik').forEach(modalKapat);
});

// Konum popup'ı
$('[data-yer]').textContent = AYAR.yerAdi;
$('#konumHot').addEventListener('click', () => modalAc('#konumModal'));
$('#btnGidelim').addEventListener('click', () => {
  window.open(AYAR.haritaURL, '_blank', 'noopener');
  modalKapat($('#konumModal'));
});

// Katılım popup'ı
$('#katilHot').addEventListener('click', () => { kutlama(); modalAc('#katilModal'); });
$('#btnWhatsapp').addEventListener('click', () => {
  const url = 'https://wa.me/' + AYAR.whatsappNo + '?text=' + encodeURIComponent(AYAR.whatsappMesaj);
  window.open(url, '_blank', 'noopener');
  modalKapat($('#katilModal'));
});

/* Kutlama konfetisi (butona basınca) */
function kutlama(){
  const frg = document.createDocumentFragment();
  const parcalar = [];
  for (let i = 0; i < 36; i++){
    const p = document.createElement('span');
    p.className = 'konfeti';
    p.style.cssText = `left:${38 + Math.random()*24}%;top:76%;background:${RENK[i%RENK.length]};
      animation:none;opacity:.95;transition:transform 1.15s cubic-bezier(.2,.7,.35,1),opacity 1.15s ease`;
    frg.appendChild(p); parcalar.push(p);
  }
  efekt.appendChild(frg);
  requestAnimationFrame(() => parcalar.forEach(p => {
    const aci = Math.random() * Math.PI * 2, uz = 80 + Math.random() * 180;
    p.style.transform = `translate3d(${Math.cos(aci)*uz}px, ${Math.sin(aci)*uz - 60}px, 0) rotate(${Math.random()*720}deg)`;
    p.style.opacity = 0;
  }));
  setTimeout(() => parcalar.forEach(p => p.remove()), 1400);
}

/* --------------------------------------------------------------------------
   9) OPSİYONEL KARAKTER KATMANLARI
   assets/katmanlar/ içine tasarımcının şeffaf PNG'leri konursa
   (panda.png, tavsan.png, aslan.png, zurafa.png, balonlar.png)
   göz kırpma / el sallama / kulak oynatma otomatik devreye girer.
   Dosya yoksa hiçbir şey olmaz, tasarım aynen kalır.  Ayrıntı: README.md
   -------------------------------------------------------------------------- */
const KARAKTERLER = [
  { dosya:'panda.png',    kutu:[262,262,215,255], anim:'elSalla'     },
  { dosya:'tavsan.png',   kutu:[470,330,150,200], anim:'kulakOynat'  },
  { dosya:'aslan.png',    kutu:[630,330,175,190], anim:'elSalla'     },
  { dosya:'zurafa.png',   kutu:[800,290,150,230], anim:'gozKirp'     },
  { dosya:'balonlar.png', kutu:[520,230,180,220], anim:'salin'       }
];

KARAKTERLER.forEach((k, i) => {
  const img = new Image();
  img.onload = () => {
    img.className = 'karakter';
    img.dataset.anim = k.anim; img.alt = '';
    Object.assign(img.style, yuzde(...k.kutu));
    img.style.animationDelay = (i * .7) + 's';
    img.style.zIndex = 7;
    kamera.appendChild(img);
  };
  img.onerror = () => {};                     // katman yoksa sessizce geç
  img.src = 'assets/katmanlar/' + k.dosya;
});
